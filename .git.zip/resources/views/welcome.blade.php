<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>
    <h1>Welcome to Hotel Booking System</h1>

    <a href="{{ route('login') }}">Login</a> |
    <a href="{{ route('register') }}">Register</a>
</body>
</html>
