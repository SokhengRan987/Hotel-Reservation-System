

<?php $__env->startSection('page-title', 'Rooms'); ?>

<?php $__env->startSection('content'); ?>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <h2 style="font-size:20px;">Rooms</h2>
    <a href="<?php echo e(route('admin.rooms.create')); ?>" class="btn-small">+ Add Room</a>
</div>

<?php if(session('success')): ?>
    <div style="margin-bottom:15px; padding:10px; background:#e6fffa; color:#065f46; border-radius:6px;"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table style="width:100%; border-collapse:collapse;">
    <thead>
        <tr style="background:#f3f4f6;">
            <th style="padding:10px; text-align:left;">Number</th>
            <th style="padding:10px; text-align:left;">Type</th>
            <th style="padding:10px; text-align:left;">Price</th>
            <th style="padding:10px; text-align:left;">Capacity</th>
            <th style="padding:10px; text-align:left;">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="padding:10px;"><?php echo e($room->number); ?></td>
                <td style="padding:10px;"><?php echo e($room->type); ?></td>
                <td style="padding:10px;">$<?php echo e(number_format($room->price,2)); ?></td>
                <td style="padding:10px;"><?php echo e($room->capacity); ?></td>
                <td style="padding:10px;">
                    <a href="<?php echo e(route('admin.rooms.edit', $room->id)); ?>" class="action-btn">Edit</a>
                    <form action="<?php echo e(route('admin.rooms.destroy', $room->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="action-btn delete" onclick="return confirm('Delete this room?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div style="margin-top:20px;">
    <?php echo e($rooms->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hotel_Booking_PPY3\resources\views/admin/rooms/index.blade.php ENDPATH**/ ?>