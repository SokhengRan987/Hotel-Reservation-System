<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($title ?? 'Hotel Booking'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?> <!-- or your Tailwind setup -->
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <?php echo e($slot); ?>

</body>
</html>
<?php /**PATH D:\Hotel_Booking_PPY3\resources\views/components/guest-layout.blade.php ENDPATH**/ ?>