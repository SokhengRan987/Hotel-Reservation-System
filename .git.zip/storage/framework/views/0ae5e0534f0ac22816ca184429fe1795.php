

<?php $__env->startSection('page-title', 'Edit Room'); ?>

<?php $__env->startSection('content'); ?>

<h2 style="margin-bottom:15px;">Edit Room - <?php echo e($room->number); ?></h2>

<?php if($errors->any()): ?>
    <div style="margin-bottom:15px; padding:10px; background:#fee2e2; color:#7f1d1d; border-radius:6px;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('admin.rooms.update', $room->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div style="margin-bottom:10px;">
        <label>Number</label><br>
        <input type="text" name="number" value="<?php echo e(old('number', $room->number)); ?>" required />
    </div>
    <div style="margin-bottom:10px;">
        <label>Type</label><br>
        <input type="text" name="type" value="<?php echo e(old('type', $room->type)); ?>" required />
    </div>
    <div style="margin-bottom:10px;">
        <label>Price</label><br>
        <input type="number" step="0.01" name="price" value="<?php echo e(old('price', $room->price)); ?>" required />
    </div>
    <div style="margin-bottom:10px;">
        <label>Capacity</label><br>
        <input type="number" name="capacity" value="<?php echo e(old('capacity', $room->capacity)); ?>" required />
    </div>
    <div style="margin-bottom:10px;">
        <label>Features (comma-separated)</label><br>
        <input type="text" name="features" value="<?php echo e(old('features', $room->features ? implode(', ', $room->features) : '')); ?>" />
    </div>
    <div style="margin-bottom:10px;">
        <label>Description</label><br>
        <textarea name="description"><?php echo e(old('description', $room->description)); ?></textarea>
    </div>
    <button class="btn-small">Save Changes</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hotel_Booking_PPY3\resources\views/admin/rooms/edit.blade.php ENDPATH**/ ?>